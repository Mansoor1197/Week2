package com.cg.store;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class StoreTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {

	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@Test
	void testCalculation() {
		Store store = new Store();
		assertEquals(700, store.Calculation(1000, 1));
	}

	@Test
	void testCalculation1() {
		Store store = new Store();
		assertEquals(900, store.Calculation(1000, 2));
	}

	@Test
	void testCalculation2() {
		Store store = new Store();
		assertEquals(950, store.Calculation(1000, 3));
	}

	@Test
	void testCalculation3() {
		Store store = new Store();
		assertEquals(700, store.Calculation(1000, 1));
	}

}
